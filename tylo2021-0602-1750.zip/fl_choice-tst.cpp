#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/fl_ask.H>

void wcb(Fl_Widget* w, void *v) {

   if(fl_choice("Quit?", "No", 0, "Yes") == 2)
// if(fl_ask("Quit?") == 1)
      w->hide();
}

int main() {

   Fl_Window *w = new Fl_Window(100, 100, 100, 100);
   w->callback(wcb);
   w->show();
   Fl::run();
}
