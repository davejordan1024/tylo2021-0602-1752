OPTIONS.TXT    a complete list of options is at the top of opts.h

Implementation of options other than the default is untested. It is intended that any option specified in options.txt be read at startup and override the
baked-in default.



TMPLTS.TXT     stores the table descriptions for the games.

You may hand-edit at will, but note anything that is not part of a valid table description will at best be overwritten and will more likely cause the app to
abort.

Fields are pipe-delimited.
1)   Name of template, which will appear under "file->new"
2)   Alphabet size. Number of symbols, e.g. 27 in English (A-Z + blank).
3-5) For each symbol: the keystroke, the onscreen representation, and the symbol to copy to the clipboard (e.g. a question mark for the blank tile).
     All three of these are typically the same.
6-8) For each symbol: the point value, the given quantity, and whether it is a vowel or a consonant (0 is consonant, 1 is vowel, 2 means it can be either).
     Whatever order the alphabet is in, here, will be the top-to-bottom order used in a game.
     After the alphabet info comes color info, whose final encoding is yet to be determined.



GAMES.TXT     stores the game data and is overwritten every time the app executes a save.

You should never need to hand-edit it but you may before startup, while the app is not running. The record format starts with a single byte for the game status
followed by the template name from templates.txt. The rest of the fields are pipe-delimited: opponent name, start time, end time, letters in rack, letters on
board, notes length, notes text.
Letters in rack are the keystrokes, not the possibly different UI representations, e.g. a period for the blank tile keystroke
versus a bullet for the blank tile onscreen representation. To indicate an empty cell on the board or rack, filler characters can be anything other than pipe or
a character in the template's keystroke set.


